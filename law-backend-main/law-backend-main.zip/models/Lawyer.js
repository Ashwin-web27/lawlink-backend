import mongoose from "mongoose";

const LawyerSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, required: true, unique: true },

  name: String,
  email: String,
  phone: String,


  specialization: { type: [String], default: [] },
  experienceYears: { type: Number, default: 0 },
  qualifications: { type: String, default: "" },
  barAssociation: { type: String, default: "" },

  about: { type: String, default: "" },
  photo: { type: String, default: "" }
}, { timestamps: true });

export default mongoose.models.Lawyer || mongoose.model("Lawyer", LawyerSchema);
