import User from "../models/User.js";
import Lawyer from "../models/Lawyer.js";
import jwt from "jsonwebtoken";

// REGISTER
export const register = async (req, res) => {
  try {
    const {
      name,
      email,
      phone,
      password,
      role,
      specialization,
      experienceYears,
      qualifications,
      barAssociation
    } = req.body;

    // Required validation
    if (!name || !email || !phone || !password || !role) {
      return res.status(400).json({
        success: false,
        error: "All required fields must be filled."
      });
    }

    // Check if user already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({
        success: false,
        error: "Email already registered"
      });
    }

    // 1️⃣ CREATE USER ACCOUNT
    const newUser = await User.create({
      name,
      email,
      phone,
      password,
      role
    });

    // 2️⃣ IF LAWYER → CREATE PROFILE
    if (role === "lawyer") {
      await Lawyer.create({
        userId: newUser._id,
        name,
        email,
        phone,
        specialization: specialization
          ? specialization.split(",").map(s => s.trim())
          : [],
        experienceYears: experienceYears ? Number(experienceYears) : 0,
        qualifications: qualifications || "",
        barAssociation: barAssociation || "",
        about: "",
        photo: ""  // default blank
      });
    }

    return res.json({
      success: true,
      message: "Registered successfully",
      userId: newUser._id,
      role
    });

  } catch (err) {
    console.error("REGISTER ERROR:", err);
    return res.status(500).json({
      success: false,
      error: "Server error"
    });
  }
};

// LOGIN
export const login = async (req, res) => {
  try {
    const { email, password, role } = req.body;

    if (!email || !password || !role) {
      return res.status(400).json({
        success: false,
        error: "Email, password and role are required"
      });
    }

    const user = await User.findOne({ email, role });

    if (!user) {
      return res.status(404).json({
        success: false,
        error: "Account not found"
      });
    }

    if (user.password !== password) {
      return res.status(400).json({
        success: false,
        error: "Incorrect password"
      });
    }

    let lawyerProfile = null;

    if (role === "lawyer") {
      lawyerProfile = await Lawyer.findOne({ userId: user._id });

      if (!lawyerProfile) {
        return res.status(400).json({
          success: false,
          error: "Lawyer profile missing. Contact support."
        });
      }
    }

    const token = jwt.sign(
      { id: user._id, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: "7d" }
    );

    return res.json({
      success: true,
      message: "Login successful",
      role: user.role,
      token,
      userId: user._id,
      lawyerProfile
    });

  } catch (err) {
    console.error("LOGIN ERROR:", err);
    return res.status(500).json({
      success: false,
      error: "Server error"
    });
  }
};
