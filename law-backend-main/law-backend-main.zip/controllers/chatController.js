import { GoogleGenerativeAI } from "@google/generative-ai";
import UserQuery from "../models/UserQuery.js";
import dotenv from "dotenv";

dotenv.config();

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

// Clean Gemini reply & remove repeated user text
function cleanReply(userMessage, aiReply) {
  if (!aiReply) return "";

  const lowerUser = userMessage.toLowerCase().trim();
  let cleaned = aiReply.trim();

  // Remove user message repeated at start
  if (cleaned.toLowerCase().startsWith(lowerUser)) {
    cleaned = cleaned.slice(userMessage.length).trim();
  }

  // Remove user message anywhere
  cleaned = cleaned.replace(new RegExp(userMessage, "gi"), "").trim();

  return cleaned;
}

export const generateReply = async (req, res) => {
  try {
    const { message } = req.body;

    if (!message || message.trim() === "") {
      return res.status(400).json({ error: "Message is required" });
    }

    // Use your available model
    const model = genAI.getGenerativeModel({
      model: "models/gemini-2.5-flash",
    });

    // SYSTEM INSTRUCTION – Indian Law Only
    const systemPrompt = `
You are a legal assistant trained ONLY on **Indian law**.

You must:
- Give answers strictly based on Indian laws, IPC, CrPC, Evidence Act, Constitution of India, Indian Contract Act, Family Law, Property Law, IT Act, Consumer Law, Labour Law, and other Indian statutes.
- Avoid mentioning US/UK/foreign laws.
- If the question is not related to Indian law, politely say you can only guide on Indian legal matters.
- Provide clear explanations in simple language.
- Avoid giving professional legal advice; instead give general legal information and suggest consulting a qualified advocate.

Now answer the user's question.
`;

    // Send message to Gemini
    const result = await model.generateContent([
      { text: systemPrompt },
      { text: message }
    ]);

    const rawReply = result.response.text();
    const reply = cleanReply(message, rawReply);

    // Save to DB
    const saved = await UserQuery.create({
      userQuery: message,
      botReply: reply,
    });

    return res.json({
      success: true,
      reply,
      saved,
    });

  } catch (error) {
    console.error("GEMINI CHAT ERROR:", error);
    res.status(500).json({
      error: "Gemini error. Try again.",
      details: error.message,
    });
  }
};
