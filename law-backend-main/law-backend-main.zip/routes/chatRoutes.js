import express from "express";
import { generateReply } from "../controllers/chatController.js";

const router = express.Router();

// Test route - so "/api/chat" works in browser
router.get("/", (req, res) => {
  res.send("Chat API is running ✔");
});

// Main chatbot route
router.post("/ask", generateReply);

export default router;
