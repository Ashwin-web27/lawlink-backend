import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import connectDB from "./config/db.js";

import chatRoutes from "./routes/chatRoutes.js";
import authRoutes from "./routes/authRoutes.js";
import appointmentRoutes from "./routes/appointmentRoutes.js";
import lawyerRoutes from "./routes/lawyerRoutes.js";

dotenv.config();
const app = express();

// --------------------
// MUST BE FIRST
// --------------------
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// --------------------
// CORS FIX
// --------------------
app.use(cors({
  origin: "http://localhost:5173",
  methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"],
  allowedHeaders: ["Content-Type", "Authorization"],
  credentials: true
}));

// --------------------
// DB CONNECT
// --------------------
connectDB();

// --------------------
// DEBUG LOGGER
// --------------------
app.use((req, res, next) => {
  console.log("---- NEW REQUEST ----");
  console.log("URL:", req.url);
  console.log("Method:", req.method);
  console.log("Body:", req.body);
  next();
});

// --------------------
// ROUTES (JSON FIRST)
// --------------------
app.use("/api/auth", authRoutes);
app.use("/api/chat", chatRoutes);
app.use("/api/appointments", appointmentRoutes);

// --------------------
// MULTER ROUTES LAST
// --------------------
app.use("/api/lawyer", lawyerRoutes);

// --------------------
// STATIC FILES
// --------------------
app.use("/uploads", express.static("uploads"));

// --------------------
// DEFAULT
// --------------------
app.get("/", (req, res) => res.send("Backend running"));

const PORT = process.env.PORT || 8000;
app.listen(PORT, () => console.log(`Backend running on port ${PORT}`));
